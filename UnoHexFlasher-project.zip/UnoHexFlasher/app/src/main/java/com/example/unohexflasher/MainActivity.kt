package com.example.unohexflasher

import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import androidx.activity.ComponentActivity
import android.hardware.usb.UsbDevice
import android.hardware.usb.UsbManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.view.ViewGroup
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.ScrollView
import android.widget.TextView
import androidx.activity.result.contract.ActivityResultContracts
import com.hoho.android.usbserial.driver.UsbSerialPort
import com.hoho.android.usbserial.driver.UsbSerialProber
import com.hoho.android.usbserial.driver.ProbeTable
import com.hoho.android.usbserial.driver.UsbSerialDriver
import com.hoho.android.usbserial.util.SerialInputOutputManager
import java.io.BufferedReader
import java.io.InputStreamReader
import java.util.concurrent.Executors
import java.util.concurrent.atomic.AtomicBoolean

class MainActivity : ComponentActivity() {
    private lateinit var chooseButton: Button
    private lateinit var flashButton: Button
    private lateinit var progress: ProgressBar
    private lateinit var logView: TextView
    private var selectedHex: ByteArray? = null
    private var selectedName: String = ""
    private val worker = Executors.newSingleThreadExecutor()
    private val busy = AtomicBoolean(false)
    private lateinit var usbManager: UsbManager
    private var permissionDevice: UsbDevice? = null
    private val permissionAction = "com.example.unohexflasher.USB_PERMISSION"

    private val pickHex = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri: Uri? ->
        if (uri != null) loadHex(uri)
    }

    private val permissionReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context, intent: Intent) {
            if (intent.action != permissionAction) return
            val device = if (Build.VERSION.SDK_INT >= 33)
                intent.getParcelableExtra(UsbManager.EXTRA_DEVICE, UsbDevice::class.java)
            else @Suppress("DEPRECATION") intent.getParcelableExtra(UsbManager.EXTRA_DEVICE)
            val granted = intent.getBooleanExtra(UsbManager.EXTRA_PERMISSION_GRANTED, false)
            if (granted && device != null) {
                appendLog("Permissão USB concedida.")
                beginFlash(device)
            } else appendLog("Permissão USB negada.")
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        usbManager = getSystemService(Context.USB_SERVICE) as UsbManager
        buildUi()
        val filter = IntentFilter(permissionAction)
        if (Build.VERSION.SDK_INT >= 33) registerReceiver(permissionReceiver, filter, Context.RECEIVER_NOT_EXPORTED)
        else @Suppress("DEPRECATION") registerReceiver(permissionReceiver, filter)
        appendLog("Conecte o Arduino Uno por cabo OTG. USB CH340 esperado: VID 1A86 / PID 7523.")
    }

    private fun buildUi() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(20, 24, 20, 20)
            layoutParams = ViewGroup.LayoutParams(-1, -1)
        }
        chooseButton = Button(this).apply {
            text = "Escolher .hex"
            setOnClickListener { pickHex.launch(arrayOf("*/*")) }
        }
        flashButton = Button(this).apply {
            text = "Gravar"
            isEnabled = false
            setOnClickListener { requestUsbAndFlash() }
        }
        progress = ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal).apply {
            max = 100
            progress = 0
        }
        logView = TextView(this).apply {
            textSize = 13f
            setTextIsSelectable(true)
            text = ""
        }
        val scroll = ScrollView(this).apply { addView(logView) }
        root.addView(chooseButton, LinearLayout.LayoutParams(-1, -2))
        root.addView(flashButton, LinearLayout.LayoutParams(-1, -2))
        root.addView(progress, LinearLayout.LayoutParams(-1, 24).apply { topMargin = 12; bottomMargin = 12 })
        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))
        setContentView(root)
    }

    private fun loadHex(uri: Uri) {
        try {
            val bytes = contentResolver.openInputStream(uri)?.use { it.readBytes() }
                ?: error("Não foi possível abrir o arquivo.")
            // Validate before enabling the flash button.
            val image = IntelHex.parse(bytes.toString(Charsets.US_ASCII))
            selectedHex = image
            selectedName = uri.lastPathSegment ?: "arquivo.hex"
            flashButton.isEnabled = true
            appendLog("HEX carregado: $selectedName (${image.size} bytes após preenchimento).")
        } catch (e: Exception) {
            selectedHex = null
            flashButton.isEnabled = false
            appendLog("Erro ao ler HEX: ${e.message ?: e.javaClass.simpleName}")
        }
    }

    private fun requestUsbAndFlash() {
        if (busy.get()) return
        val device = usbManager.deviceList.values.firstOrNull {
            it.vendorId == 0x1A86 && it.productId == 0x7523
        }
        if (device == null) {
            appendLog("CH340 não encontrado. Confira o cabo OTG, a alimentação e o adaptador.")
            return
        }
        if (usbManager.hasPermission(device)) beginFlash(device)
        else {
            permissionDevice = device
            val intent = Intent(permissionAction).setPackage(packageName)
            val flags = PendingIntent.FLAG_UPDATE_CURRENT or
                (if (Build.VERSION.SDK_INT >= 31) PendingIntent.FLAG_MUTABLE else 0)
            val pending = PendingIntent.getBroadcast(this, 0, intent, flags)
            usbManager.requestPermission(device, pending)
            appendLog("Solicitando permissão USB…")
        }
    }

    private fun beginFlash(device: UsbDevice) {
        val image = selectedHex ?: run { appendLog("Escolha um arquivo .hex primeiro."); return }
        if (!busy.compareAndSet(false, true)) return
        runOnUiThread {
            flashButton.isEnabled = false
            chooseButton.isEnabled = false
            progress.progress = 0
        }
        worker.execute {
            var port: UsbSerialPort? = null
            var connection: android.hardware.usb.UsbDeviceConnection? = null
            try {
                val table = ProbeTable().apply {
                    addProduct(0x1A86, 0x7523, com.hoho.android.usbserial.driver.Ch34xSerialDriver::class.java)
                }
                val driver = UsbSerialProber(table).probeDevice(device)
                    ?: error("Driver CH34x não reconheceu o dispositivo.")
                connection = usbManager.openDevice(device) ?: error("Não foi possível abrir o dispositivo USB.")
                val serial = driver.ports.firstOrNull() ?: error("Porta serial USB não encontrada.")
                port = serial
                serial.open(connection)
                serial.setParameters(115200, 8, UsbSerialPort.STOPBITS_1, UsbSerialPort.PARITY_NONE)
                serial.setDTR(false)
                serial.setRTS(false)
                appendLog("CH340 aberto a 115200 baud.")
                // Reset automático do Arduino: liga DTR/RTS, solta, e deixa o Optiboot iniciar.
                val resetBoard = {
                    serial.setDTR(true)
                    serial.setRTS(true)
                    Thread.sleep(250)
                    serial.setDTR(false)
                    serial.setRTS(false)
                    Thread.sleep(50)
                    drain(serial)
                }
                val flasher = Stk500(serial, resetBoard) { done, total, msg ->
                    runOnUiThread {
                        progress.progress = if (total == 0) 0 else (done * 100 / total)
                        if (msg.isNotBlank()) appendLog(msg)
                    }
                }
                flasher.flash(image)
                appendLog("GRAVAÇÃO CONCLUÍDA. Verificação de todas as páginas OK.")
            } catch (e: Exception) {
                appendLog("FALHA: ${e.message ?: e.javaClass.simpleName}")
            } finally {
                try { port?.close() } catch (_: Exception) {}
                try { connection?.close() } catch (_: Exception) {}
                busy.set(false)
                runOnUiThread {
                    flashButton.isEnabled = selectedHex != null
                    chooseButton.isEnabled = true
                }
            }
        }
    }

    private fun drain(port: UsbSerialPort) {
        val buf = ByteArray(256)
        repeat(8) {
            try {
                val n = port.read(buf, 40)
                if (n <= 0) return
            } catch (_: Exception) { return }
        }
    }

    private fun appendLog(message: String) {
        runOnUiThread {
            logView.append(message + "\n")
        }
    }

    override fun onDestroy() {
        try { unregisterReceiver(permissionReceiver) } catch (_: Exception) {}
        worker.shutdownNow()
        super.onDestroy()
    }
}

private object IntelHex {
    private const val PAGE = 128

    fun parse(text: String): ByteArray {
        val memory = sortedMapOf<Long, Int>()
        var upper = 0L
        var eof = false
        var highest = -1L
        text.lineSequence().map { it.trim() }.filter { it.isNotEmpty() }.forEachIndexed { idx, line ->
            require(!eof) { "Dados encontrados após EOF (linha ${idx + 1})." }
            require(line.startsWith(":")) { "Registro inválido na linha ${idx + 1}." }
            val raw = line.substring(1)
            require(raw.length % 2 == 0 && raw.length >= 10) { "HEX malformado na linha ${idx + 1}." }
            val record = raw.chunked(2).map { it.toInt(16) }
            val count = record[0]
            require(record.size == count + 5) { "Tamanho incorreto na linha ${idx + 1}." }
            require((record.sum() and 0xFF) == 0) { "Checksum incorreto na linha ${idx + 1}." }
            val addr = (record[1] shl 8) or record[2]
            val type = record[3]
            val data = record.subList(4, 4 + count)
            when (type) {
                0x00 -> {
                    val start = upper + addr
                    data.forEachIndexed { i, value ->
                        val absolute = start + i
                        require(absolute < 32768L) { "HEX ultrapassa os 32 KiB de flash do ATmega328P." }
                        memory[absolute] = value
                        if (absolute > highest) highest = absolute
                    }
                }
                0x01 -> { require(count == 0); eof = true }
                0x02 -> { require(count == 2); upper = (((data[0] shl 8) or data[1]).toLong()) shl 4 }
                0x04 -> { require(count == 2); upper = (((data[0] shl 8) or data[1]).toLong()) shl 16 }
                else -> error("Tipo Intel HEX não suportado: %02X".format(type))
            }
        }
        require(eof) { "Registro EOF (01) ausente." }
        require(highest >= 0) { "O HEX não contém dados de programa." }
        val size = (((highest + 1 + PAGE - 1) / PAGE) * PAGE).toInt()
        val result = ByteArray(size) { 0xFF.toByte() }
        memory.forEach { (address, value) -> result[address.toInt()] = value.toByte() }
        return result
    }
}

private class Stk500(
    private val port: UsbSerialPort,
    private val resetBoard: () -> Unit,
    private val report: (done: Int, total: Int, message: String) -> Unit
) {
    private val timeoutMs = 700
    private val INSYNC = 0x14
    private val OK = 0x10
    private val PAGE = 128

    fun flash(image: ByteArray) {
        require(image.isNotEmpty() && image.size % PAGE == 0) { "Tamanho de imagem inválido." }
        sync()
        command(byteArrayOf(0x50, 0x20), 2)
        val pages = image.size / PAGE
        for (page in 0 until pages) {
            val byteAddress = page * PAGE
            val wordAddress = byteAddress / 2
            command(byteArrayOf(0x55, (wordAddress and 0xFF).toByte(), ((wordAddress shr 8) and 0xFF).toByte(), 0x20), 2)
            val payload = ByteArray(4 + PAGE + 1)
            payload[0] = 0x64
            payload[1] = 0x00
            payload[2] = 0x80.toByte()
            payload[3] = 0x46
            System.arraycopy(image, byteAddress, payload, 4, PAGE)
            payload[payload.size - 1] = 0x20
            command(payload, 2)
            // Read back page for verification.
            command(byteArrayOf(0x55, (wordAddress and 0xFF).toByte(), ((wordAddress shr 8) and 0xFF).toByte(), 0x20), 2)
            val readCommand = byteArrayOf(0x74, 0x00, 0x80.toByte(), 0x46, 0x20)
            write(readCommand)
            val response = readExact(PAGE + 2)
            if ((response[0].toInt() and 0xFF) != INSYNC ||
                (response.last().toInt() and 0xFF) != OK) {
                error("Resposta de leitura inválida na página $page.")
            }
            for (i in 0 until PAGE) {
                if (response[i + 1] != image[byteAddress + i]) {
                    error("Verificação falhou na página $page, byte ${i}.")
                }
            }
            report(page + 1, pages, "Página ${page + 1}/$pages gravada e verificada.")
        }
        command(byteArrayOf(0x51, 0x20), 2)
        report(pages, pages, "Saída do modo de programação.")
    }

    private fun sync() {
        var last: Exception? = null
        repeat(3) { round ->
            resetBoard()
            repeat(10) { attempt ->
                try {
                    clearInput()
                    write(byteArrayOf(0x30, 0x20))
                    val response = readExact(2, 250)
                    if ((response[0].toInt() and 0xFF) == INSYNC &&
                        (response[1].toInt() and 0xFF) == OK) {
                        report(0, 1, "Sincronização STK500v1 OK (rodada ${round + 1}, tentativa ${attempt + 1}).")
                        return
                    }
                    last = IllegalStateException("Resposta de sincronização inesperada.")
                } catch (e: Exception) { last = e }
                Thread.sleep(20)
            }
            report(0, 1, "Sem resposta do bootloader, resetando de novo…")
        }
        throw IllegalStateException("Não foi possível sincronizar com o Optiboot.", last)
    }

    private fun command(bytes: ByteArray, expected: Int) {
        write(bytes)
        val response = readExact(expected)
        if ((response[0].toInt() and 0xFF) != INSYNC ||
            (response[1].toInt() and 0xFF) != OK) {
            error("Resposta STK500 inválida para comando 0x%02X.".format(bytes[0].toInt() and 0xFF))
        }
    }

    private fun write(bytes: ByteArray) {
        port.write(bytes, timeoutMs)
    }

    private var pending = ByteArray(0)

    private fun readExact(length: Int, totalTimeoutMs: Long = timeoutMs * 4L): ByteArray {
        val start = System.currentTimeMillis()
        while (pending.size < length) {
            if (System.currentTimeMillis() - start > totalTimeoutMs) {
                error("Timeout aguardando resposta do bootloader (${pending.size}/$length bytes).")
            }
            val chunk = ByteArray(512)
            val count = port.read(chunk, 100)
            if (count > 0) pending += chunk.copyOf(count)
        }
        val result = pending.copyOf(length)
        pending = pending.copyOfRange(length, pending.size)
        return result
    }

    private fun clearInput() {
        pending = ByteArray(0)
        val buffer = ByteArray(256)
        repeat(5) {
            try { if (port.read(buffer, 30) <= 0) return } catch (_: Exception) { return }
        }
    }
}
