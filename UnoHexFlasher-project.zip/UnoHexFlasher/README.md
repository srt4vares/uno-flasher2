# Uno HEX Flasher

Aplicativo Android nativo em Kotlin para gravar Intel HEX em Arduino Uno / ATmega328P com bootloader Optiboot, usando USB OTG e CH340 (VID `1A86`, PID `7523`), sem root.

## Construir
Abra a pasta no Android Studio (JDK 17; Android SDK 35) e execute `assembleDebug`, ou envie para GitHub e execute a action **Build debug APK**. O APK aparece em **Actions → Build debug APK → Artifacts → UnoHexFlasher-debug**.

## Uso
1. Conecte o Uno ao telefone por OTG e aceite a permissão USB.
2. Toque em **Escolher .hex** e selecione o arquivo Intel HEX.
3. Toque em **Gravar** e mantenha o cabo conectado até a verificação terminar.

O app valida checksums e EOF, entende registros Intel HEX 00/01/02/04, limita a imagem aos 32 KiB de flash e preenche lacunas até múltiplo de 128 bytes com `0xFF`. Cada página é lida de volta e comparada.

## Notas
- O driver `usb-serial-for-android` configura o CH340 para 115200 8N1 e controla DTR/RTS.
- A rotina faz reset automático por DTR/RTS, sincroniza com STK500v1 e grava/verifica páginas de 128 bytes.
- Não inclui bootloader nem grava fuses; apenas a aplicação no espaço de flash.
- O workflow compila com Gradle instalado na imagem Ubuntu do GitHub Actions.
